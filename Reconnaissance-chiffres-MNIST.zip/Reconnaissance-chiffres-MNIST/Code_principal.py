import numpy as np
import matplotlib.pyplot as plt
from utils import get_images_and_labels, visualisation_poids, charger_et_vectoriser_image, plot_precision

# importation du dataset
images, labels = get_images_and_labels("train")

# // afficher 36 images aléatoires de la base d’apprentissage avec leur chiffre associé
def afficher_exemples(images,labels):
    plt.figure(1)
    for i in range(36):
        ind =  np.random.randint(len(images)) # 1.4 // indice aléatoire pour choisir l'image
        image = images[ind] # // image correspondante à l'indice
        plt.subplot(6, 6, i+1)
        plt.imshow(image, cmap='gray')
        plt.title(str(labels[ind]), fontsize=8) # // label correspondant à l'image
        plt.axis('off')
    plt.tight_layout()
    plt.show()


#// transformer le label en vecteur de sortie désirée pour l'apprentissage.
#// Par exemple, si label =3, la sortie sera le vecteur [0,0,0,1,0,0,0,0,0,0]
def calcul_sd(label):
    S_d = np.zeros((10,1))
    S_d[label] = 1
    return S_d

#// Fonction d'activation du neurone
def sigmoid(x):
    return 1/(1+np.exp(-x))

def forward(E, W1, W2):
    E_biais = np.vstack(([1],E)) # Ajout du biais, vstack colle les vecteurs/tableaux l'un au-dessus de l'autre ( empilement vertical)
    Z1 = W1 @ E_biais # pareil que np.dot(W1, E_biais;)
    S1 = sigmoid(Z1)
    S1_biais = np.vstack(([1], S1))
    Z2 = W2 @S1_biais
    S = sigmoid(Z2)
    
    return S1, S

# Rétropropagation : fonction complète, ne pas modifier !
def backprop(S, S_d, S1, nu, W1, W2, E):

    # ---- Couche 2 ----
    # Ajout biais à S1 pour correspondre à la taille de W2
    S1_biais = np.vstack(([1], S1))                        

    # Calcul de sigma pour la couche de sortie
    sigma2 = (S - S_d) * S * (1 - S)                        

    # Mise à jour des poids de la couche 2
    W2 -= nu * sigma2 @ S1_biais.T                         

    # ---- Couche 1 ----
    # Propagation de l'erreur pour chaque neurone de la couche 1
    sigma1 = (W2[:, 1:].T @ sigma2) * S1 * (1 - S1)        

    # Ajout biais à E
    E_biais = np.vstack(([1], E))

    # Mise à jour des poids de la couche 1
    W1 -= nu * sigma1 @ E_biais.T                          

    return W1, W2

# Fonction qui calcule la précision du réseau
def calcul_precision(W1,W2):
    images, labels = get_images_and_labels("??") # !
    N = images.shape[0]
    n_corrects = 0
    for ind in range(N):
        
        E = images[ind].reshape(-1, 1)
        _, S = forward(E, W1, W2)
        prediction = np.argmax(S)
        
        if prediction == labels[ind]:
            n_corrects +=1
        
    return n_corrects / N


# Fonction qui teste le réseau sur un échantillon d'images inconnues    
def test_reseau(W1, W2):
    
    images, labels = get_images_and_labels("??") # !
    
    plt.figure(6)
    plt.clf()
    plt.colormaps()
    plt.gray()

    for i in range(36):
        plt.subplot(6, 6, i+1)
        ind = np.random.randint(images.shape[0])
        E = images[ind].reshape(-1, 1)
        
        _, S = forward(E, W1, W2)
        prediction = np.argmax(S)
        confiance = np.max(S)

        image = E.reshape(28, 28)
        plt.imshow(image, cmap='gray')
        plt.title(f"{prediction} ({confiance:.2f})", fontsize=8)
        plt.axis('off')

    plt.tight_layout()
    plt.show()
    plt.pause(0.1)

# %%

####### ---------------------------- Premiers tests ------------------------------ #######
# Chargement du dictionnaire
images, labels = get_images_and_labels("train") # !!! 1.4

# Affichage de 36 échantillons aléatoires du dictionnaire
afficher_exemples(images,labels)



# %%

####### ---------------------------- Entrainement du modèle ------------------------------ #######
# Chargement du dictionnaire
images, labels = get_images_and_labels("train") # !!! 1.4

# Initialisation des paramètres 
# 2.1 - Nombres de neurones par couche
n_0 = 784 # ! Couche d'entrée
n_1 = 32 # ! Couche cachée
n_2 = 10 # ! Couche de sortie

# 2.2 - Matrices de paramètres
W_1 = np.random.uniform(-1,1,(n_1,n_0+1)) # ! Matrice des paramètres de la couche cachée
W_2 = np.random.uniform(-1,1,(n_2,n_1+1)) # ! Matrice des paramètres de la couche de sortie

# 2.5 - Paramètres de l'apprentissage
nb_iter = 10000
nu = 0.1

# Variables pour le diagnostic
historique_precision = []

# Entraînement
for iter in range(nb_iter):

    # Sélection aléatoire d’un échantillon
    ind = np.random.randint(len(images))
    
    # Construction de l'entrée du réseau
    E = images[ind].reshape(-1, 1)  

    # Calcul de la sortie désirée
    S_d = calcul_sd(labels[ind])

    # Entrainement du réseau (1 itération
    S1, S = forward(E,W_1,W_2)
    W_1,W_2 = backprop(S, S_d, S1, nu, W_1, W_2, E)
    
    # #Affichage de l'évolution de la précision du réseau
    # if (iter + 1) % 1000 == 0:
    #     prec = calcul_precision(W_1,W_2)
    #     historique_precision.append(prec)
    #     plot_precision(historique_precision, interval=1000)
    #     print(f"Precision : {calcul_precision(W_1,W_2)}")
   
    # # Visualisation du modèle interne du réseau
    # if (iter + 1) % 1000 == 0:
    #     visualisation_poids(W_1,W_2)


plt.show()

# %%
####### ---------------------------- Utilisation du modèle ------------------------------ #######

def test_paint(image, W1, W2):
    # Chargement et conversion de l’image
    E = charger_et_vectoriser_image("Chemin d'acces")
    
    # Affichage de l’image
    plt.figure(7)
    plt.imshow(E.reshape(28, 28), cmap='gray')
    plt.axis('off')

    # Prédiction par le réseau
    _, S = forward(E, W1, W2)
    prediction = np.argmax(S)
    confiance = np.max(S)

    plt.title(f"Il s'agit d'un {prediction} avec une probabilité de {confiance:.2f}")
    plt.show()
    
test_paint("Chemin d'acces", W_1, W_2)
